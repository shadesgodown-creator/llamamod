package net.mcreator.llamamod.procedures;

import net.mcreator.llamamod.LlamaModModElements;

import java.util.Map;

@LlamaModModElements.ModElement.Tag
public class TestProcedure extends LlamaModModElements.ModElement {
	public TestProcedure(LlamaModModElements instance) {
		super(instance, 80);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
